@echo off
REM Requires JDK 17, Gradle 8.13, and Android SDK Platform 35.
gradle assembleDebug
if errorlevel 1 exit /b %errorlevel%
echo.
echo APK: app\build\outputs\apk\debug\app-debug.apk
