# PhantomTrace 1.0.0

A local Android activity-forensics utility built for Android 8.0+ and tested-by-design against the Android 13 permission model. The initial target device is an Infinix Hot 40 Pro running Android 13.

## What it does

### 1. Forensic history
- Uses `UsageStatsManager.queryEvents()` to import activity foreground/background transitions and selected screen/lock events that Android still retains.
- Reads aggregated foreground-use time by app for the last seven days.
- Shows package name, event type, source API, and timestamp.
- Keeps an app-private SQLite event log and exports it as CSV.

### 2. Realtime monitoring
- A user-started foreground service polls Usage Events every six seconds while Android keeps the service alive.
- A small overlap between polls reduces missed events; SQLite de-duplicates repeated rows.
- The foreground notification has a Stop action.
- Monitoring is not hidden, does not start at boot, and does not silently start itself.

### 3. Media-session inspection
- Optional `NotificationListenerService` access lets Android expose active media sessions through `MediaSessionManager`.
- PhantomTrace records only the media app package and when a session changes into/out of the playing state.
- It deliberately does **not** inspect notification title/body, chat text, images, or media metadata.
- Audio that plays without an Android media session (for example, some ad/WebView/native audio paths) may not be attributable. This is an Android platform limitation, not proof that nothing played.

### 4. Device context
- Shows a current battery percentage, battery temperature, charging state, and Android thermal status when available.
- These are current snapshots, not historical per-app battery/CPU measurements.

## Important limits

- Android documents that Usage Events are retained only for a few days. A scan may therefore find some activity from before PhantomTrace was installed, but cannot promise it. The OS/OEM may return a shorter or incomplete history.
- Usage Access is a special app-op and must be enabled manually in Android Settings. Installing the app does not grant it automatically.
- Media-session visibility requires the user to enable PhantomTrace under Notification Access. This is a powerful Android permission. The listener implementation in this project intentionally does not read notification content.
- Realtime monitoring is best-effort. Android, XOS battery management, force-stop, reboot, or memory pressure can interrupt it. It is not a guaranteed system-wide recorder.
- This is an evidence viewer/collector, not an antivirus engine. A package appearing in a log is not by itself evidence of malware.
- This app cannot recover deleted system logs, inspect another app's private files, or retroactively identify the source of arbitrary sound if Android did not expose a corresponding usage/media event.

## Privacy and permissions

Manifest permissions are limited to:

- `PACKAGE_USAGE_STATS` — special Usage Access setting.
- `FOREGROUND_SERVICE` — visible, user-started realtime monitoring.
- `POST_NOTIFICATIONS` — Android 13 notification permission.
- A declared `NotificationListenerService` protected binding — optional media-session visibility after the user explicitly enables it.

There is no `INTERNET`, `RECORD_AUDIO`, `READ_SMS`, `QUERY_ALL_PACKAGES`, Accessibility Service, root requirement, or boot receiver. The database remains in the app's private storage. Logs older than 30 days are trimmed. CSV export is initiated by the user.

## Install/use on the Android 13 phone

1. Install the debug APK produced by the build instructions below.
2. Open PhantomTrace and tap **Open Usage Access Settings**.
3. Find PhantomTrace and enable **Permit usage access**.
4. Return to PhantomTrace and run **Forensic Scan · Last 7 Days**.
5. Optional: tap **Open Notification / Media Access Settings**, enable PhantomTrace, then return. Enable this only if you are comfortable granting the system's Notification Access permission; the app code does not read notification text.
6. Tap **Start Realtime Monitor** when you want a visible monitoring session. Use the app's Stop button or the persistent notification's Stop action to end it.
7. Export a CSV before clearing logs if you need a copy.

On Infinix/XOS, battery-management settings may stop long-running background services. Keep the PhantomTrace foreground notification visible while testing. Do not expect the monitor to survive a force-stop or reboot.

## Build the APK

This delivery is an **Android Studio project source ZIP**, not an APK. Renaming a ZIP to `.apk` will not create an installable Android application: an APK needs compiled DEX code, Android resources/manifest packaging, and an APK signature.

Build requirements:

- Android Studio with Android SDK Platform 35 installed.
- JDK 17.
- Android Gradle Plugin 8.13.0 and Gradle 8.13.

Steps:

1. Extract the ZIP on a computer with Android Studio.
2. Open the extracted `PhantomTrace` folder (the folder containing `settings.gradle`).
3. Set the Gradle JDK to JDK 17 and use a local Gradle 8.13 installation. If your Android Studio expects a wrapper, generate the wrapper once from the project root with `gradle wrapper --gradle-version 8.13` (requires Gradle 8.13 installed).
4. Sync the project. Install Android SDK Platform 35 if Android Studio prompts for it.
5. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. The debug APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.

The debug build uses application ID `com.affan.phantomtrace.debug`. The release variant uses `com.affan.phantomtrace` and needs a signing key configured by the builder.

## Project layout

- `app/src/main/AndroidManifest.xml` — application declarations and services.
- `MainActivity.java` — dashboard, permission links, scan controls, CSV export.
- `UsageScanner.java` — historical and polling Usage Events retrieval.
- `ActivityMonitorService.java` — visible foreground service and media-session state changes.
- `MediaAccessListener.java` — minimal Notification Listener component; no notification content parsing.
- `EventDatabase.java` — private SQLite log and CSV export.

## Build status of this delivery

The source project and configuration files are included. This workspace does not contain Android SDK build tools or Gradle, so an APK could not be compiled or runtime-tested here. The project should be synced and built in Android Studio with the versions above; compilation on a real Android SDK remains the final verification step.
