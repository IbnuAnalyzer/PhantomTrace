# No custom rules required; minification is disabled for the first release.
