package com.affan.phantomtrace;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.os.Build;
import android.graphics.drawable.Icon;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.provider.Settings;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class ActivityMonitorService extends Service {
    static final String ACTION_STOP = "com.affan.phantomtrace.STOP_MONITOR";
    private static final String CHANNEL_ID = "phantomtrace_monitor";
    private static final int NOTIFICATION_ID = 7401;
    private static final long POLL_INTERVAL_MS = 6000L;
    private static final long AUDIO_POLL_INTERVAL_MS = 10000L;

    private HandlerThread workerThread;
    private Handler worker;
    private EventDatabase database;
    private SharedPreferences preferences;
    private long cursor;
    private long lastAudioPoll;
    private final Set<String> activeMediaPackages = new HashSet<>();

    private final Runnable pollTask = new Runnable() {
        @Override public void run() {
            long now = System.currentTimeMillis();
            if (UsageScanner.hasUsageAccess(ActivityMonitorService.this)) {
                // Small overlap avoids losing events that arrive close to a polling boundary.
                UsageScanner.collectEvents(ActivityMonitorService.this, database,
                        Math.max(0L, cursor - 1500L), now);
                cursor = now;
                preferences.edit().putLong("monitor_cursor", cursor).apply();
            }
            if (now - lastAudioPoll >= AUDIO_POLL_INTERVAL_MS) {
                inspectMediaSessions(now);
                lastAudioPoll = now;
            }
            if (worker != null) worker.postDelayed(this, POLL_INTERVAL_MS);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        database = new EventDatabase(this);
        preferences = getSharedPreferences("phantomtrace", MODE_PRIVATE);
        workerThread = new HandlerThread("PhantomTraceMonitor");
        workerThread.start();
        worker = new Handler(workerThread.getLooper());
        createNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopMonitoring();
            return START_NOT_STICKY;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForeground(NOTIFICATION_ID, buildNotification());
        }
        boolean explicitStart = intent != null;
        cursor = explicitStart
                ? System.currentTimeMillis()
                : preferences.getLong("monitor_cursor", System.currentTimeMillis());
        preferences.edit().putBoolean("monitor_requested", true).putLong("monitor_cursor", cursor).apply();
        worker.removeCallbacks(pollTask);
        worker.post(pollTask);
        return START_STICKY;
    }

    private void inspectMediaSessions(long now) {
        if (!isNotificationListenerEnabled()) return;
        try {
            MediaSessionManager manager = (MediaSessionManager) getSystemService(Context.MEDIA_SESSION_SERVICE);
            if (manager == null) return;
            ComponentName listener = new ComponentName(this, MediaAccessListener.class);
            List<MediaController> sessions = manager.getActiveSessions(listener);
            Set<String> playingNow = new HashSet<>();
            if (sessions != null) {
                for (MediaController controller : sessions) {
                    if (controller == null) continue;
                    PlaybackState state = controller.getPlaybackState();
                    if (state != null && state.getState() == PlaybackState.STATE_PLAYING) {
                        String pkg = controller.getPackageName();
                        if (pkg != null && !pkg.equals(getPackageName())) {
                            playingNow.add(pkg);
                            if (!activeMediaPackages.contains(pkg)) {
                                database.addEvent(now, pkg, "MEDIA_SESSION_PLAYING", "MEDIA_SESSION");
                            }
                        }
                    }
                }
            }
            for (String previous : activeMediaPackages) {
                if (!playingNow.contains(previous)) {
                    database.addEvent(now, previous, "MEDIA_SESSION_NO_LONGER_PLAYING", "MEDIA_SESSION");
                }
            }
            activeMediaPackages.clear();
            activeMediaPackages.addAll(playingNow);
        } catch (SecurityException ignored) {
            // The user may have revoked Notification Listener access while monitoring.
        } catch (RuntimeException ignored) {
            // OEM media-session implementations can occasionally reject a query.
        }
    }

    static boolean isNotificationListenerEnabled(Context context) {
        String enabled = Settings.Secure.getString(context.getContentResolver(),
                "enabled_notification_listeners");
        if (enabled == null) return false;
        String own = new ComponentName(context, MediaAccessListener.class).flattenToString();
        return enabled.contains(own);
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent contentIntent = PendingIntent.getActivity(this, 10, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, ActivityMonitorService.class).setAction(ACTION_STOP);
        PendingIntent stopIntent = PendingIntent.getService(this, 11, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_search)
                .setContentTitle("PhantomTrace sedang memantau")
                .setContentText("Mengumpulkan event penggunaan secara lokal")
                .setContentIntent(contentIntent)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .addAction(new Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_media_pause), "Hentikan", stopIntent).build())
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    getString(com.affan.phantomtrace.R.string.notification_channel),
                    NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Status pemantauan PhantomTrace yang dimulai pengguna");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void stopMonitoring() {
        preferences.edit().putBoolean("monitor_requested", false).apply();
        if (worker != null) worker.removeCallbacksAndMessages(null);
        stopForeground(true);
        stopSelf();
    }

    @Override public void onDestroy() {
        if (worker != null) worker.removeCallbacksAndMessages(null);
        if (workerThread != null) workerThread.quitSafely();
        if (preferences != null) preferences.edit().putBoolean("monitor_requested", false).apply();
        if (database != null) database.close();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
