package com.affan.phantomtrace;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

final class EventDatabase extends SQLiteOpenHelper {
    private static final String DB_NAME = "phantomtrace.db";
    private static final int DB_VERSION = 1;

    EventDatabase(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE events (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "event_time INTEGER NOT NULL," +
                "package_name TEXT NOT NULL DEFAULT ''," +
                "event_type TEXT NOT NULL," +
                "source TEXT NOT NULL," +
                "UNIQUE(event_time, package_name, event_type, source) ON CONFLICT IGNORE)");
        db.execSQL("CREATE INDEX idx_events_time ON events(event_time DESC)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Preserve existing logs when upgrading. Add explicit migrations here in future versions.
    }

    synchronized boolean addEvent(long time, String packageName, String type, String source) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("event_time", time);
        values.put("package_name", packageName == null ? "" : packageName);
        values.put("event_type", type);
        values.put("source", source);
        long rowId = db.insertWithOnConflict("events", null, values, SQLiteDatabase.CONFLICT_IGNORE);
        // Keep the local database bounded; logs older than 30 days are trimmed.
        db.delete("events", "event_time < ?", new String[]{String.valueOf(System.currentTimeMillis() - 30L * 24L * 60L * 60L * 1000L)});
        return rowId != -1;
    }

    synchronized List<EventRecord> recentEvents(int limit) {
        List<EventRecord> rows = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT event_time, package_name, event_type, source FROM events ORDER BY event_time DESC LIMIT ?",
                new String[]{String.valueOf(Math.max(1, Math.min(limit, 500)))})) {
            while (c.moveToNext()) {
                rows.add(new EventRecord(c.getLong(0), c.getString(1), c.getString(2), c.getString(3)));
            }
        }
        return rows;
    }

    synchronized int count() {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM events", null)) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    synchronized void clear() {
        getWritableDatabase().delete("events", null, null);
    }

    synchronized void exportCsv(OutputStream output) throws IOException {
        String header = "timestamp_iso,epoch_millis,package_name,event_type,source\n";
        output.write(header.getBytes(StandardCharsets.UTF_8));
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT event_time, package_name, event_type, source FROM events ORDER BY event_time ASC", null)) {
            while (c.moveToNext()) {
                long time = c.getLong(0);
                String iso = java.time.Instant.ofEpochMilli(time).toString();
                String line = csv(iso) + "," + time + "," + csv(c.getString(1)) + "," +
                        csv(c.getString(2)) + "," + csv(c.getString(3)) + "\n";
                output.write(line.getBytes(StandardCharsets.UTF_8));
            }
        }
        output.flush();
    }

    private static String csv(String value) {
        String safe = value == null ? "" : value;
        return "\"" + safe.replace("\"", "\"\"") + "\"";
    }
}
