package com.affan.phantomtrace;

final class EventRecord {
    final long time;
    final String packageName;
    final String type;
    final String source;

    EventRecord(long time, String packageName, String type, String source) {
        this.time = time;
        this.packageName = packageName == null ? "" : packageName;
        this.type = type == null ? "UNKNOWN" : type;
        this.source = source == null ? "UNKNOWN" : source;
    }
}
