package com.affan.phantomtrace;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.BatteryManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final int REQUEST_NOTIFICATIONS = 501;
    private static final int REQUEST_EXPORT = 502;
    private static final int COLOR_BG = Color.rgb(11, 16, 22);
    private static final int COLOR_CARD = Color.rgb(19, 29, 39);
    private static final int COLOR_TEXT = Color.rgb(232, 240, 245);
    private static final int COLOR_MUTED = Color.rgb(154, 171, 184);
    private static final int COLOR_ACCENT = Color.rgb(112, 225, 183);
    private static final int COLOR_WARN = Color.rgb(255, 194, 107);

    private EventDatabase database;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private LinearLayout content;
    private TextView usageStatus;
    private TextView mediaStatus;
    private TextView monitorStatus;
    private TextView batteryStatus;
    private TextView eventCount;
    private TextView scanMessage;
    private LinearLayout topAppsBox;
    private LinearLayout eventListBox;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(COLOR_BG);
        getWindow().setNavigationBarColor(COLOR_BG);
        database = new EventDatabase(this);
        buildUi();
        refreshDashboard();
    }

    @Override protected void onResume() {
        super.onResume();
        if (content != null) refreshDashboard();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(COLOR_BG);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(18), dp(18), dp(28));
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));
        setContentView(scroll);

        TextView eyebrow = text("ANDROID ACTIVITY FORENSICS", 11, COLOR_ACCENT, true);
        eyebrow.setLetterSpacing(0.12f);
        content.addView(eyebrow);
        TextView title = text("PHANTOMTRACE", 28, COLOR_TEXT, true);
        title.setPadding(0, dp(5), 0, 0);
        content.addView(title);
        TextView subtitle = text("Hybrid monitor · local-only diagnostics", 13, COLOR_MUTED, false);
        content.addView(subtitle);

        LinearLayout statusCard = card();
        statusCard.setPadding(dp(14), dp(14), dp(14), dp(14));
        addLabel(statusCard, "PERMISSION STATUS");
        usageStatus = addStatusRow(statusCard, "Usage Access", "Checking…");
        mediaStatus = addStatusRow(statusCard, "Media-session access", "Checking…");
        monitorStatus = addStatusRow(statusCard, "Realtime monitor", "Standby");
        content.addView(statusCard, paramsTop(16));

        Button usageButton = button("OPEN USAGE ACCESS SETTINGS");
        usageButton.setOnClickListener(v -> openUsageSettings());
        content.addView(usageButton, paramsTop(10));
        Button mediaButton = button("OPEN NOTIFICATION / MEDIA ACCESS SETTINGS");
        mediaButton.setOnClickListener(v -> openMediaSettings());
        content.addView(mediaButton, paramsTop(8));

        LinearLayout actions = card();
        actions.setPadding(dp(14), dp(14), dp(14), dp(14));
        addLabel(actions, "INVESTIGATION CONTROLS");
        Button scanButton = button("RUN FORENSIC SCAN · LAST 7 DAYS");
        scanButton.setOnClickListener(v -> runForensicScan());
        actions.addView(scanButton, paramsTop(10));
        Button startButton = button("START REALTIME MONITOR");
        startButton.setOnClickListener(v -> startMonitor());
        actions.addView(startButton, paramsTop(8));
        Button stopButton = button("STOP REALTIME MONITOR");
        stopButton.setOnClickListener(v -> stopMonitor());
        actions.addView(stopButton, paramsTop(8));
        content.addView(actions, paramsTop(14));

        LinearLayout scanCard = card();
        scanCard.setPadding(dp(14), dp(14), dp(14), dp(14));
        addLabel(scanCard, "FORENSIC SCAN RESULT");
        scanMessage = text("Belum ada pemindaian. Berikan Usage Access, lalu jalankan scan.", 13, COLOR_MUTED, false);
        scanMessage.setPadding(0, dp(8), 0, 0);
        scanCard.addView(scanMessage);
        TextView topTitle = text("TOP APPS BY FOREGROUND TIME", 11, COLOR_ACCENT, true);
        topTitle.setPadding(0, dp(16), 0, dp(6));
        scanCard.addView(topTitle);
        topAppsBox = new LinearLayout(this);
        topAppsBox.setOrientation(LinearLayout.VERTICAL);
        scanCard.addView(topAppsBox);
        content.addView(scanCard, paramsTop(14));

        LinearLayout deviceCard = card();
        deviceCard.setPadding(dp(14), dp(14), dp(14), dp(14));
        addLabel(deviceCard, "DEVICE CONTEXT");
        batteryStatus = text("Reading device state…", 13, COLOR_TEXT, false);
        batteryStatus.setPadding(0, dp(8), 0, 0);
        deviceCard.addView(batteryStatus);
        content.addView(deviceCard, paramsTop(14));

        LinearLayout logsCard = card();
        logsCard.setPadding(dp(14), dp(14), dp(14), dp(14));
        LinearLayout logHeader = new LinearLayout(this);
        logHeader.setGravity(Gravity.CENTER_VERTICAL);
        logHeader.setOrientation(LinearLayout.HORIZONTAL);
        addLabel(logHeader, "LOCAL EVENT LOG");
        eventCount = text("0 events", 11, COLOR_MUTED, false);
        logHeader.addView(eventCount, new LinearLayout.LayoutParams(-2, -2));
        logsCard.addView(logHeader);
        Button export = button("EXPORT CSV");
        export.setOnClickListener(v -> exportCsv());
        logsCard.addView(export, paramsTop(10));
        Button clear = button("CLEAR LOCAL LOGS");
        clear.setOnClickListener(v -> confirmClearLogs());
        logsCard.addView(clear, paramsTop(7));
        eventListBox = new LinearLayout(this);
        eventListBox.setOrientation(LinearLayout.VERTICAL);
        eventListBox.setPadding(0, dp(10), 0, 0);
        logsCard.addView(eventListBox);
        content.addView(logsCard, paramsTop(14));

        LinearLayout privacyCard = card();
        privacyCard.setPadding(dp(14), dp(14), dp(14), dp(14));
        addLabel(privacyCard, "PRIVACY & LIMITS");
        TextView privacy = text(
                "• No internet permission; records stay in this app's private storage.\n" +
                "• No microphone recording, notification text, message content, or other apps' private files.\n" +
                "• Pre-install history is only what Android still retains and exposes. Usage events are kept by Android for a few days, not indefinitely.\n" +
                "• Media detection only sees active media sessions exposed after Notification Listener is enabled. Ads or sounds without a media session may remain unattributed.\n" +
                "• Realtime polling is best-effort; Android/OEM battery management can stop it.",
                12, COLOR_MUTED, false);
        privacy.setPadding(0, dp(8), 0, 0);
        privacyCard.addView(privacy);
        content.addView(privacyCard, paramsTop(14));

        TextView footer = text("PHANTOMTRACE 1.0.0 · NO ROOT REQUIRED", 10, COLOR_MUTED, true);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(18), 0, 0);
        content.addView(footer);
    }

    private void refreshDashboard() {
        boolean usage = UsageScanner.hasUsageAccess(this);
        boolean media = ActivityMonitorService.isNotificationListenerEnabled(this);
        usageStatus.setText(usage ? "Granted" : "Not granted — tap button above");
        usageStatus.setTextColor(usage ? COLOR_ACCENT : COLOR_WARN);
        mediaStatus.setText(media ? "Enabled" : "Optional — not enabled");
        mediaStatus.setTextColor(media ? COLOR_ACCENT : COLOR_WARN);
        boolean running = getSharedPreferences("phantomtrace", MODE_PRIVATE)
                .getBoolean("monitor_requested", false);
        monitorStatus.setText(running ? "Requested / may be running" : "Standby");
        monitorStatus.setTextColor(running ? COLOR_ACCENT : COLOR_MUTED);
        batteryStatus.setText(readDeviceContext());
        eventCount.setText(database.count() + " events stored");
        renderRecentEvents(database.recentEvents(35));
    }

    private void runForensicScan() {
        if (!UsageScanner.hasUsageAccess(this)) {
            Toast.makeText(this, "Aktifkan Usage Access terlebih dahulu.", Toast.LENGTH_LONG).show();
            openUsageSettings();
            return;
        }
        scanMessage.setText("Scanning available Android usage history…");
        topAppsBox.removeAllViews();
        io.execute(() -> {
            UsageScanner.ScanResult result = UsageScanner.scanHistory(this, database, 7);
            runOnUiThread(() -> {
                scanMessage.setText(result.message + "\nEvent baru diimpor: " + result.importedEvents);
                renderTopApps(result.topApps);
                refreshDashboard();
            });
        });
    }

    private void renderTopApps(List<UsageScanner.TopApp> apps) {
        topAppsBox.removeAllViews();
        if (apps == null || apps.isEmpty()) {
            topAppsBox.addView(text("Tidak ada statistik aplikasi yang tersedia untuk rentang ini.", 12, COLOR_MUTED, false));
            return;
        }
        int rank = 1;
        for (UsageScanner.TopApp app : apps) {
            String label = appLabel(app.packageName);
            long minutes = app.foregroundMs / 60000L;
            long hours = minutes / 60L;
            long rem = minutes % 60L;
            String duration = hours > 0 ? hours + " jam " + rem + " menit" : rem + " menit";
            topAppsBox.addView(text(rank++ + ". " + label + "  ·  " + duration + "\n" + app.packageName,
                    12, COLOR_TEXT, false), paramsTop(5));
        }
    }

    private void renderRecentEvents(List<EventRecord> rows) {
        eventListBox.removeAllViews();
        if (rows.isEmpty()) {
            eventListBox.addView(text("Belum ada event tersimpan.", 12, COLOR_MUTED, false));
            return;
        }
        DateFormat format = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM);
        for (EventRecord row : rows) {
            String who = row.packageName.isEmpty() ? "Android system" : appLabel(row.packageName);
            TextView line = text(row.type + "  ·  " + who + "\n" + format.format(new Date(row.time)) +
                    "  ·  " + row.source, 12, COLOR_TEXT, false);
            line.setPadding(0, dp(7), 0, dp(7));
            eventListBox.addView(line);
            View divider = new View(this);
            divider.setBackgroundColor(Color.rgb(42, 55, 67));
            eventListBox.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));
        }
    }

    private void startMonitor() {
        if (!UsageScanner.hasUsageAccess(this)) {
            Toast.makeText(this, "Aktifkan Usage Access dulu.", Toast.LENGTH_LONG).show();
            openUsageSettings();
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
            return;
        }
        startMonitorServiceNow();
    }

    private void startMonitorServiceNow() {
        Intent intent = new Intent(this, ActivityMonitorService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent);
        else startService(intent);
        Toast.makeText(this, "Realtime monitor dimulai.", Toast.LENGTH_SHORT).show();
        refreshDashboard();
    }

    private void stopMonitor() {
        Intent intent = new Intent(this, ActivityMonitorService.class).setAction(ActivityMonitorService.ACTION_STOP);
        startService(intent);
        Toast.makeText(this, "Perintah stop dikirim.", Toast.LENGTH_SHORT).show();
        monitorStatus.setText("Stop requested");
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQUEST_NOTIFICATIONS) {
            // Monitoring is user-initiated. Android may still show the FGS in Task Manager
            // even when notification drawer permission is denied.
            startMonitorServiceNow();
        }
    }

    private void openUsageSettings() {
        try { startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)); }
        catch (Exception e) { Toast.makeText(this, "Menu Usage Access tidak tersedia.", Toast.LENGTH_LONG).show(); }
    }

    private void openMediaSettings() {
        try { startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); }
        catch (Exception e) { Toast.makeText(this, "Menu Notification Access tidak tersedia.", Toast.LENGTH_LONG).show(); }
    }

    private void exportCsv() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/csv");
        intent.putExtra(Intent.EXTRA_TITLE, "phantomtrace-events.csv");
        startActivityForResult(intent, REQUEST_EXPORT);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_EXPORT && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri == null) return;
            io.execute(() -> {
                try (java.io.OutputStream stream = getContentResolver().openOutputStream(uri, "wt")) {
                    if (stream == null) throw new java.io.IOException("Tidak bisa membuka file tujuan");
                    database.exportCsv(stream);
                    runOnUiThread(() -> Toast.makeText(this, "CSV berhasil diekspor.", Toast.LENGTH_LONG).show());
                } catch (Exception e) {
                    runOnUiThread(() -> Toast.makeText(this, "Ekspor gagal: " + e.getMessage(), Toast.LENGTH_LONG).show());
                }
            });
        }
    }

    private void confirmClearLogs() {
        new AlertDialog.Builder(this)
                .setTitle("Hapus semua log lokal?")
                .setMessage("Tindakan ini menghapus database event PhantomTrace di perangkat. Data Android di luar aplikasi tidak akan dihapus.")
                .setNegativeButton("Batal", null)
                .setPositiveButton("Hapus", (dialog, which) -> {
                    io.execute(() -> {
                        database.clear();
                        runOnUiThread(this::refreshDashboard);
                    });
                }).show();
    }

    private String readDeviceContext() {
        StringBuilder result = new StringBuilder();
        try {
            Intent battery = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (battery != null) {
                int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                int temp = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
                int status = battery.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                if (level >= 0 && scale > 0) result.append("Battery: ").append(Math.round(level * 100f / scale)).append("%\n");
                if (temp != Integer.MIN_VALUE) result.append("Battery temperature: ").append(String.format(java.util.Locale.US, "%.1f°C", temp / 10f)).append("\n");
                result.append("Power: ").append(status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL ? "charging / full" : "not charging");
            }
        } catch (Exception ignored) { result.append("Battery information unavailable"); }
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                PowerManager power = (PowerManager) getSystemService(Context.POWER_SERVICE);
                if (power != null) {
                    int thermal = power.getCurrentThermalStatus();
                    result.append("\nThermal status: ").append(thermalLabel(thermal));
                }
            } catch (Exception ignored) {}
        }
        result.append("\nNote: snapshot saat ini, bukan riwayat suhu/baterai per aplikasi.");
        return result.toString();
    }

    private String thermalLabel(int value) {
        switch (value) {
            case PowerManager.THERMAL_STATUS_NONE: return "normal";
            case PowerManager.THERMAL_STATUS_LIGHT: return "light";
            case PowerManager.THERMAL_STATUS_MODERATE: return "moderate";
            case PowerManager.THERMAL_STATUS_SEVERE: return "severe";
            case PowerManager.THERMAL_STATUS_CRITICAL: return "critical";
            case PowerManager.THERMAL_STATUS_EMERGENCY: return "emergency";
            case PowerManager.THERMAL_STATUS_SHUTDOWN: return "shutdown threshold";
            default: return "unknown";
        }
    }

    private String appLabel(String packageName) {
        try {
            return String.valueOf(getPackageManager().getApplicationLabel(
                    getPackageManager().getApplicationInfo(packageName, 0)));
        } catch (Exception ignored) { return packageName; }
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(COLOR_CARD);
        return box;
    }

    private void addLabel(LinearLayout parent, String value) {
        parent.addView(text(value, 11, COLOR_ACCENT, true));
    }

    private TextView addStatusRow(LinearLayout parent, String label, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView left = text(label, 13, COLOR_MUTED, false);
        row.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView right = text(value, 12, COLOR_TEXT, true);
        right.setGravity(Gravity.RIGHT);
        row.addView(right, new LinearLayout.LayoutParams(-2, -2));
        row.setPadding(0, dp(10), 0, 0);
        parent.addView(row);
        return right;
    }

    private TextView text(String value, int sizeSp, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sizeSp);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private Button button(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(12);
        button.setTextColor(COLOR_BG);
        button.setAllCaps(false);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(COLOR_ACCENT));
        button.setMinHeight(dp(46));
        return button;
    }

    private LinearLayout.LayoutParams paramsTop(int topDp) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(topDp);
        return params;
    }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
}
