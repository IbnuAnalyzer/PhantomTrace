package com.affan.phantomtrace;

import android.service.notification.NotificationListenerService;

/**
 * Intentionally does not read notification text, titles, images, or message contents.
 * Android requires an enabled notification listener to expose active media sessions
 * through MediaSessionManager to a normal third-party application.
 */
public final class MediaAccessListener extends NotificationListenerService {
}
