package com.affan.phantomtrace;

import android.app.AppOpsManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.os.Build;
import android.os.Process;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

final class UsageScanner {
    private UsageScanner() {}

    static boolean hasUsageAccess(Context context) {
        try {
            AppOpsManager appOps = (AppOpsManager) context.getSystemService(Context.APP_OPS_SERVICE);
            if (appOps == null) return false;
            int mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(), context.getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Exception ignored) {
            return false;
        }
    }

    static ScanResult scanHistory(Context context, EventDatabase database, int days) {
        if (!hasUsageAccess(context)) {
            return new ScanResult(false, 0, "Usage Access belum diizinkan di Pengaturan Android.", new ArrayList<>());
        }
        UsageStatsManager manager = (UsageStatsManager) context.getSystemService(Context.USAGE_STATS_SERVICE);
        if (manager == null) {
            return new ScanResult(false, 0, "UsageStatsManager tidak tersedia pada perangkat ini.", new ArrayList<>());
        }

        long end = System.currentTimeMillis();
        long begin = end - Math.max(1, days) * 24L * 60L * 60L * 1000L;
        int imported = collectEvents(context, database, begin, end);
        List<TopApp> topApps = queryTopApps(context, manager, begin, end);
        String note = "Pemindaian selesai. Android hanya menyimpan event penggunaan untuk rentang terbatas; data sebelum instalasi bisa tersedia, tetapi tidak dijamin.";
        return new ScanResult(true, imported, note, topApps);
    }

    static int collectEvents(Context context, EventDatabase database, long begin, long end) {
        if (!hasUsageAccess(context)) return 0;
        UsageStatsManager manager = (UsageStatsManager) context.getSystemService(Context.USAGE_STATS_SERVICE);
        if (manager == null) return 0;
        UsageEvents events;
        try {
            events = manager.queryEvents(begin, end);
        } catch (RuntimeException e) {
            return 0;
        }
        if (events == null) return 0;

        int added = 0;
        UsageEvents.Event event = new UsageEvents.Event();
        while (events.hasNextEvent()) {
            events.getNextEvent(event);
            String type = mapEventType(event.getEventType());
            if (type == null) continue;
            String pkg = event.getPackageName();
            if (pkg != null && pkg.equals(context.getPackageName())) continue;
            if (database.addEvent(event.getTimeStamp(), pkg, type, "USAGE_STATS")) added++;
        }
        return added;
    }

    private static String mapEventType(int eventType) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (eventType == UsageEvents.Event.ACTIVITY_RESUMED) return "APP_FOREGROUND";
            if (eventType == UsageEvents.Event.ACTIVITY_PAUSED) return "APP_BACKGROUND";
        }
        if (eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) return "APP_FOREGROUND";
        if (eventType == UsageEvents.Event.MOVE_TO_BACKGROUND) return "APP_BACKGROUND";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            if (eventType == UsageEvents.Event.SCREEN_INTERACTIVE) return "SCREEN_INTERACTIVE";
            if (eventType == UsageEvents.Event.SCREEN_NON_INTERACTIVE) return "SCREEN_NON_INTERACTIVE";
            if (eventType == UsageEvents.Event.KEYGUARD_SHOWN) return "LOCKSCREEN_SHOWN";
            if (eventType == UsageEvents.Event.KEYGUARD_HIDDEN) return "LOCKSCREEN_HIDDEN";
        }
        return null;
    }

    private static List<TopApp> queryTopApps(Context context, UsageStatsManager manager, long begin, long end) {
        Map<String, Long> totals = new HashMap<>();
        try {
            List<UsageStats> stats = manager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, begin, end);
            if (stats != null) {
                for (UsageStats stat : stats) {
                    String pkg = stat.getPackageName();
                    if (pkg == null || pkg.equals(context.getPackageName())) continue;
                    totals.put(pkg, totals.getOrDefault(pkg, 0L) + stat.getTotalTimeInForeground());
                }
            }
        } catch (RuntimeException ignored) {}

        List<TopApp> result = new ArrayList<>();
        for (Map.Entry<String, Long> entry : totals.entrySet()) {
            if (entry.getValue() > 0) result.add(new TopApp(entry.getKey(), entry.getValue()));
        }
        Collections.sort(result, new Comparator<TopApp>() {
            @Override public int compare(TopApp a, TopApp b) { return Long.compare(b.foregroundMs, a.foregroundMs); }
        });
        if (result.size() > 12) return new ArrayList<>(result.subList(0, 12));
        return result;
    }

    static final class ScanResult {
        final boolean accessGranted;
        final int importedEvents;
        final String message;
        final List<TopApp> topApps;
        ScanResult(boolean accessGranted, int importedEvents, String message, List<TopApp> topApps) {
            this.accessGranted = accessGranted;
            this.importedEvents = importedEvents;
            this.message = message;
            this.topApps = topApps;
        }
    }

    static final class TopApp {
        final String packageName;
        final long foregroundMs;
        TopApp(String packageName, long foregroundMs) {
            this.packageName = packageName;
            this.foregroundMs = foregroundMs;
        }
    }
}
