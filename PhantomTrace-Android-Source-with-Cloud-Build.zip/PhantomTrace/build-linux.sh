#!/usr/bin/env sh
set -eu
# Requires JDK 17, Gradle 8.13, and Android SDK Platform 35.
gradle assembleDebug
printf '\nAPK: app/build/outputs/apk/debug/app-debug.apk\n'
